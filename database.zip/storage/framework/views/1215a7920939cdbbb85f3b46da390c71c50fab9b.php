<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/styles.css" rel="stylesheet">

    <title>Universite des comores</title>
  </head>
  <body>
    <section class="form-08">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="_form-08-main">
              <div class="_form-08-head">
                  <div class="row">
                      <div class="col-md-2"><img src="assets/images/udc.png" width="50px" height="50px"></div>
                      <div class="col-md-10">
                          <h3><strong class="text-center">Université des comores</strong></h3>
                          <h6><strong> Direction des études de la scolarité</strong></h6>
                      </div>
                  </div>
                <b style="margin-left: 60px;">Autorisation de paiement</b><br><br>
              <p style="text-align:left;">Le Directeur des Etudes et de la Scolarité, sousigné,autorise</p>
              <div class="row" style="text-align:left;">
                  <!-- <div class="col-md-2"></div> -->
              <div class="col-md-6">
                <p><b>Numero d'autorisation: <?php echo e($data->num_auto); ?></b></p>
              </div>

              <!-- <div class="col-md-2"></div> -->
            </div>
            <div class="row"  style="text-align: left;">
                <div class="col-md-6">
                  <p>Nom: <?php echo e($data->nom); ?></p>
                </div>
                <div class="col-md-6">
                 <p>prénom:  <?php echo e($data->prenom); ?></p>
                </div>
              </div>
              <div class="row"  style="text-align: left;">
                <div class="col-md-12">
                  <p>Ne(é) le: <?php echo e($data->date_naiss); ?> à <?php echo e($data->lieu_naiss); ?></p>
                </div>
              </div>
              <div class="row"  style="text-align: justify;">
                <div class="col-md-6">
                  <p>NIN: <?php echo e($data->nin); ?></p>
                </div>
                <div class="col-md-6">
                <?php if($data->matricule==NULL): ?>
                    <?php if(isset($candidats->num_recu)): ?>
                    <p>Num reçu: <?php echo e($candidats->num_recu); ?></p>
                    <?php endif; ?>
                 <?php elseif($data->matricule !=NULL): ?>
                 <p>Matricule: <?php echo e($data->matricule); ?></p>
                <?php endif; ?>
                </div>
              </div>
              <div class="row"  style="text-align: left;">
                <div class="col-md-12">
                  <p>Préinscrit au titre de l'année: <?php echo e($data->Annee); ?></p>
                </div>
              </div>
              <div class="row"  style="text-align:left;">
                <div class="col-md-12">
                  <p>Composante: <?php echo e($composante->design_facult); ?></p>
                </div>
              </div>
              <div class="row"  style="text-align:left;">
                <div class="col-md-12">
                  <p>Département: <?php echo e($departement->design_depart); ?></p>
                </div>
              </div>
              <div class="row"  style="text-align: justify;">
                <div class="col-md-12">
                  <p>Niveau: <?php echo e($niveau->intit_niv); ?></p>
                </div>
              </div>
              <div class="row" style="text-align:left;">
                <p>à verser à la BDC</p>
                <p><?php echo e($data->droit); ?> (<?php echo e($data->droit_lettre); ?> Francs Comorien) de frais d'inscription au compte UDC</p>
            </div>
            <?php if( $s->date_fin >= $date ): ?>
            <div class="row">
                <form method="post" action="<?php echo e(url('https://26901.tagpay.fr/online/online.php')); ?>" >
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="sessionid" value="<?php echo e($sessionId); ?>">
                    <input type="hidden" name="merchantid" value="2532345689566942">
                    <input type="hidden" name="amount"  value="<?php echo e($data->droit); ?>">
                    <input type="hidden" name="currency" value="174">
                    <input type="hidden" name="purchaseref" value=" <?php echo e($data->nin); ?>">
                    <input type="hidden" name="accepturl" value="https://autorisation.univ-comores.km/accepturl">
                    <input type="hidden" name="cancelurl" value="https://autorisation.univ-comores.km/cancelurl">
                    <input type="hidden" name="declineurl" value="https://autorisation.univ-comores.km/declineurl">
                    <input type="submit" class="btn btn-sm btn-primary" name="ok" value="Payer via Holo">
                    <a href="<?php echo e(route('accueil')); ?>" class="btn btn-sm btn-primary">Payer après</a>
                </form>
            </div>
            <?php endif; ?>
              <!-- <div class="form-group">
                <div class="_btn_04">
                  <a href="choix.html">Debuter l'inscription</a>
                </div>
                <p style="text-align:center;" class="fiche"><a href="#">Cliquez ici si vous avez deja une fiche</a></p>
              </div>
              <div class="sub-01">
                <img src="assets/images/shap-02.png">
              </div> -->
          </div>
        </div>
      </div>
    </section>
  </body>
</html>
<?php /**PATH /home/udc/public_html/Doc_Autorisation/resources/views/autorisation.blade.php ENDPATH**/ ?>