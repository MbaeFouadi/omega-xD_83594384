<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    <title>Université des Comores</title>
  </head>
  <body>
    <section class="form-08">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="_form-08-main">
              <div class="_form-08-head">
                <h2>Recherche Fiche de renseignement</h2>
                <?php if(isset($message)): ?>
                    <div class="alert alert-danger col-md-12"><?php echo e($message); ?></div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('renseignement')); ?>">
                <?php echo csrf_field(); ?>
              </div class="row">
              <div class="form-group col-md-4">
                <input type="text" name="matricule" class="form-control" placeholder="Matricule" required="" aria-required="true">
              </div>
              
              <!-- <div class="form-group">
              <button type="submit" class="btn btn-sm btn-primary" >Validez</button>
            </div> -->
            <div class="form-group">
                <div class="row">
                    <div class="col-md-10 col-sm-6">
                    <a href="<?php echo e(route('accueil')); ?>" class="btn btn-sm btn-primary " >retour</a><br><br>
                  
                  </div>
                  <div class="col-md-2 col-sm-6">
                  <button type="submit" class="btn btn-sm btn-primary " >Valider</button>

                      
                  </div>
                </div>
              <!-- <button type="submit" class="btn btn-sm btn-primary" >Validez</button> -->
            </div>

        </form>
              <!-- <div class="form-group">
                <div class="_btn_04">
                  <a href="choix.html">Debuter l'inscription</a>
                </div>
                <p style="text-align:center;" class="fiche"><a href="#">Cliquez ici si vous avez deja une fiche</a></p>
              </div>
              <div class="sub-01">
                <img src="assets/images/shap-02.png">
              </div> -->
            </div>
          </div>
        </div>
      </div>
    </section>
  </body>
</html>
<?php /**PATH /home/udc/public_html/Doc_Autorisation/resources/views/recherche_fiche.blade.php ENDPATH**/ ?>