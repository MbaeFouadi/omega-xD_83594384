<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TypeRecuController extends Controller
{
    //
}
