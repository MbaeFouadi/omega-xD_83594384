<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BachelierController extends Controller
{
    //
}
