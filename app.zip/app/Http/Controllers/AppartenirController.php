<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AppartenirController extends Controller
{
    //
}
